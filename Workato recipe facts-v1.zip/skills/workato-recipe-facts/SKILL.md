---
name: "workato-recipe-facts"
description: "Use whenever Workato recipes or an export (zip or folder of .recipe.json files) are in play and the question is how they work, how they connect, or what uses X. Builds a SQLite fact store and answers from it, before any reading of recipe JSON by hand."
---

# Workato recipe facts

Turn a Workato export into a small SQLite fact store. Then answer from the store.

The spine is **facts → tools → judgment → evidence**.

- **Facts** come from one fixed script (at the end of this file). It reads every file the same way every time.
- **Tools** are six commands. You do not open recipe JSON to read it.
- **Judgment** is yours: explanation, diagnosis, impact.
- **Evidence** is the command, or the `recipe › step N`, behind each claim.

Why not read the JSON? A recipe file is a deep tree of ids that mean nothing by eye: step aliases, column uids, datapill blobs. Reading it costs a lot of context and produces wrong edges. A parser written fresh in each session finds slightly different facts each time. One fixed parser removes both problems, and its coverage report says what it could not read.

## 1. Build the store

Do this once per export, per session. If a store for this export already exists in the session, skip to section 2.

1. Unpack each export into its own empty folder. Keep the script in a different folder. The export is data, not code.
2. Get the script out of this file. Extract it; do not retype it:

   ```bash
   mkdir -p tools
   sed -n '/^```python$/,/^```$/p' "<base directory of this skill>/SKILL.md" | sed '1d;$d' > tools/wkfacts.py
   ```

   If this file is not on disk, write the script out exactly as it appears below.
3. Build one store per export. Name it for what it holds:

   ```bash
   python3 -I tools/wkfacts.py build exports/golden --db golden.db
   ```

   Use `python` or `py -3` where `python3` does not exist. The script needs only the standard library.
4. Read the coverage report (section 5) before you answer anything.

## 2. Commands

| Command | Use it to |
|---|---|
| `find <text>` | Find every place a name or text appears: step inputs, schemas, comments, code, pages, endpoints, connector source. It also lists the steps that use a data table column with that name. Start here. |
| `outline <recipe>` | Read one recipe as an indented step list, with conditions and targets. |
| `step <recipe> <n>` | Read one step in full: inputs with datapills shown as `<<step: path>>`, what it uses, and which later steps read its output. Add `--full` for long values such as code. |
| `q "<SELECT ...>"` | Ask anything else. Read-only. 50 rows unless `--max`. Cells are clipped. |
| `diff old.db new.db` | List the recipes, steps and other assets added, removed or changed between two exports. |
| `build <dir>` | Rebuild a store. It replaces the file. |

All commands take `--db <file>`. `<recipe>` is the file path or any unique part of the name. If it matches more than one recipe, the command lists them and stops. Then pick by path.

## 3. Orient first, then drill down

Start wide. These queries give the shape of an estate in a few rows each.

```sql
SELECT kind, COUNT(*) FROM assets GROUP BY 1 ORDER BY 2 DESC                 -- what the export holds
SELECT trigger, COUNT(*) FROM recipes GROUP BY 1 ORDER BY 2 DESC             -- how work enters
SELECT name, trigger, steps FROM recipes WHERE trigger NOT LIKE 'workato_recipe_function.%' ORDER BY 1   -- entry points
SELECT caller, step, action, callee, resolved FROM v_calls ORDER BY 1, 2     -- the call graph, endpoints and pages included
SELECT callee, COUNT(*) AS call_sites, COUNT(DISTINCT caller) AS callers FROM v_calls GROUP BY 1 ORDER BY 2 DESC   -- shared hubs
SELECT tbl, rw, recipe, step FROM v_table_use ORDER BY 1, 2, 3               -- who touches each table
SELECT name FROM recipes WHERE trigger LIKE 'workato_recipe_function.%'
  AND recipe NOT IN (SELECT target FROM edges WHERE kind = 'recipe')         -- functions nothing here calls
```

Everything that can reach one recipe (walk the callers upward):

```sql
WITH RECURSIVE up(r) AS (
  SELECT recipe FROM recipes WHERE name LIKE 'POOL-16%'
  UNION SELECT e.src FROM edges e JOIN up ON e.target = up.r WHERE e.kind = 'recipe')
SELECT COALESCE(x.name, up.r) FROM up LEFT JOIN recipes x ON x.recipe = up.r
```

Then go narrow:

| Question | Look at |
|---|---|
| Where is this name, field, message or id used? | `find <text>` |
| Who calls recipe X? Which endpoint or page starts it? | `v_calls` filtered on `callee` |
| What does X do, in order? | `outline X` |
| What exactly does step N do? Who reads its output? | `step X N` |
| What does a recipe function accept and return? | `step X 0` (the trigger holds both schemas) |
| Who reads or writes table T? | `v_table_use` |
| Who sets, filters on or reads column C? | `find C` (second block) or `v_column_use` |
| Who reads property P? | `SELECT src_name, step, field FROM v_pills WHERE property = 'P'` |
| Which steps use connector action A? | `SELECT recipe, number FROM steps WHERE action = 'A'` |
| What changed since the last export? | `diff` |

## 4. What the store holds

- `assets(path, kind, name, sha)`: every file. `kind` comes from the file name: `x.recipe.json` is a `recipe`.
- `recipes(recipe, name, code, trigger, steps, fingerprint)`: `recipe` is the file path. It is the only safe identity.
- `steps(recipe, path, number, depth, keyword, provider, action, alias, comment, fingerprint, node_json)`: `path` (`0/4/0`) is the identity. `number` is what the editor shows. `alias` is the id that datapills point at.
- `edges(src, path, field, kind, target, target_name, label, rw, resolved)`: a reference from a step, or from any other asset, to an asset. `kind` is the kind of the target. `rw` is read or write for table steps. `resolved = 0` means the target is not in this export.
- `pills(src, path, field, mode, pill_type, provider, alias, from_path, src_path, uid, property)`: one row per datapill use. `from_path` is the step that produced the value. `mode` is text, formula or legacy.
- `fields(src, path, field, value, uid)`: every leaf value of every step and of every other JSON asset. Text files such as connector source get one row per line, with `path` = `L<line>`.
- `columns(tbl, uid, name, shared)`: data table columns. Steps refer to a column by uid, never by name.
- `problems(src, path, kind, detail)` and `meta(key, value)`.
- Views add recipe names and step numbers, so prefer them: `v_edges`, `v_calls`, `v_table_use`, `v_pills`, `v_column_use`, `v_unresolved`, `v_stale_labels`, `v_problems`.

## 5. Read the coverage report

The report says how much of the export the parser understood. Check it before you trust an answer.

- **assets**: is the kind you need there? Pages, endpoints, tables, properties and connector source are present only if the export manifest included them. A missing kind means "not visible here". It does not mean "does not exist".
- **edges, unresolved**: each one is a finding. List them with `v_unresolved` and report them. The usual causes are a target in another project, a deleted target, or a call that the export could not bind.
- **pills**: most estates have many `formula` pills. None at all on a big export is suspicious.
- **columns**: `0` when table files are present means the parser did not recognize the table file shape. Open one table file, find where the column ids are, and say that column lookups are blind.
- **problems**: list them with `v_problems`.
  - `pill_source_missing`: a pill points at a step alias that no step has. That is a broken pill, or a pill form the parser does not know. Look at one with `step` before you report it.
  - `pill_unparsed`, `json_error`: content that was skipped.
  - `duplicate_code`: two recipes share a code such as `WFA-013`. Refer to them by path.
- **First time on an estate**: spot-check. Run `outline` on one recipe the user knows well and confirm that the step numbers match the editor.

## 6. Rules of evidence

- Cite the source of every factual claim: the command, or `recipe › step N (action)`.
- Say which export the answer comes from. `meta.source` holds the folder. If the folder name carries a date, give it.
- Keep facts and conclusions apart. "Step 7 calls POOL-16" is a fact. "So the invite runs on every claim" is a conclusion.
- An empty result means "none found in this export". Say what you searched for.
- A truncated result is not a count. Narrow the query or raise `--max` first.
- If a value looks like a live credential (a token, key or password), do not repeat it. Say where it is and recommend that it is rotated.

## 7. Traps

1. **Identity.** Use the file path for a recipe and `path` for a step. Codes collide (`INV-01a` and `INV-01b`, leftover copies). Step numbers shift on every edit, so give the export date with them.
2. **Binding and label.** The binding is `zip_name`. The label the editor shows can go stale after a rename. `v_stale_labels` lists these. Trust the binding.
3. **Two datapill forms.** Text mode is `#{_dp('...')}`. Formula mode is a bare `_dp('...')` in a value that starts with `=`. Both are indexed. A pill names its source by step alias, not by step number.
4. **Columns are uids.** Step inputs hold `input.parameters.<uid>`, filter values and pill paths. A text search for a column name finds only the table file. Use the second block of `find`, or `v_column_use`.
5. **System columns.** A system column such as Record ID has one uid in every table. `v_column_use` marks these `shared = 1`. Attribute them by the table of the step, not by the uid.
6. **Not every dependency is an edge.** A table reached through a custom connector, an HTTP call or Python code appears only as text. Search for the table name and the table id with `find`.
7. **Function contracts.** A recipe function declares its inputs and outputs on the trigger, in `parameters_schema_json` and `result_schema_json`. Callers pass `input.parameters.<name>`. To see what a caller reads back, run `step` on its call step and read the "read by" lines.
8. **`LIKE` wildcards.** In SQL `LIKE`, `_` matches any character. Use `find`, or `instr(value, 'text') > 0`.
9. **`rw` is a guess from the action name.** Check an unusual action with `step`.

## 8. What an export cannot show

- Job history, and which recipes are running.
- Connection credentials, collaborators, roles, API clients and keys.
- Data table rows.
- Other workspaces and environments, and any caller outside Workato.
- Developer API dumps (code stored as a string) also index, but their calls use numeric ids and stay unresolved.

Say so when a question depends on one of these. Do not guess.

## 9. The script

```python
#!/usr/bin/env python3
'''wkfacts: deterministic facts about a Workato export, in SQLite. Stdlib only.

  build <export_dir> [--db facts.db]     index every file, print a coverage report
  find <text> [--db F] [--max N]         every place a name or text appears, with its step
  q "<SELECT ...>" [--db F] [--max N]    read-only query; rows capped, cells clipped
  outline <recipe> [--db F]              one recipe as an indented step list
  step <recipe> <number> [--db F]        one step: inputs, targets, readers (--full = no clipping)
  diff <old.db> <new.db>                 what changed between two builds

<recipe> is the file path, or any unique part of the recipe name or path.
'''
import argparse, hashlib, json, os, pathlib, re, sqlite3, sys, time

VERSION = '1.0'
UUID = re.compile(r'[0-9a-f]{8}[-_][0-9a-f]{4}[-_][0-9a-f]{4}[-_][0-9a-f]{4}[-_][0-9a-f]{12}', re.I)
DP = re.compile('''_dp[(] *['"]''')
LEGACY = re.compile('''(?<![A-Za-z0-9])_[(]'([^']+)'[)]''')
CODE = re.compile(' *([A-Za-z]{1,6}(?:-[A-Za-z0-9]+)+)')
WRITE = re.compile(r'add|create|insert|update|upsert|delete|remove|truncate|write', re.I)
READ = re.compile(r'get|search|list|query|lookup|find|read|fetch', re.I)
TEXT = {'.rb', '.py', '.txt', '.md', '.yml', '.yaml'}
HIDE = {'number', 'as', 'keyword', 'uuid', 'block'}                 # step keys that are not content
BIG = {'extended_output_schema', 'extended_input_schema'}
DEC = json.JSONDecoder()
TAB, NL, BACKSLASH = chr(9), chr(10), chr(92)

SCHEMA = '''
CREATE TABLE meta(key TEXT, value TEXT);
CREATE TABLE assets(path TEXT PRIMARY KEY, kind TEXT, name TEXT, sha TEXT);
CREATE TABLE recipes(recipe TEXT PRIMARY KEY, name TEXT, code TEXT, trigger TEXT, steps INT, fingerprint TEXT);
CREATE TABLE steps(recipe TEXT, path TEXT, number INT, depth INT, keyword TEXT, provider TEXT, action TEXT,
  alias TEXT, comment TEXT, fingerprint TEXT, node_json TEXT, PRIMARY KEY(recipe, path));
CREATE TABLE edges(src TEXT, path TEXT, field TEXT, kind TEXT, target TEXT, target_name TEXT, label TEXT, rw TEXT, resolved INT);
CREATE TABLE pills(src TEXT, path TEXT, field TEXT, mode TEXT, pill_type TEXT, provider TEXT, alias TEXT,
  from_path TEXT, src_path TEXT, uid TEXT, property TEXT);
CREATE TABLE fields(src TEXT, path TEXT, field TEXT, value TEXT, uid TEXT);
CREATE TABLE columns(tbl TEXT, uid TEXT, name TEXT, shared INT DEFAULT 0);
CREATE TABLE problems(src TEXT, path TEXT, kind TEXT, detail TEXT);
CREATE INDEX i_fields ON fields(src, path); CREATE INDEX i_fuid ON fields(uid);
CREATE INDEX i_pills ON pills(src, path); CREATE INDEX i_edges ON edges(target);
CREATE VIEW v_edges AS SELECT COALESCE(r.name, e.src) AS src_name, s.number AS step, s.provider||'.'||s.action AS action,
  e.kind, COALESCE(a.name, e.target_name, e.target) AS target_name, e.rw, e.resolved, e.label, e.src, e.path, e.field, e.target
  FROM edges e LEFT JOIN recipes r ON r.recipe=e.src LEFT JOIN steps s ON s.recipe=e.src AND s.path=e.path
  LEFT JOIN assets a ON a.path=e.target;
CREATE VIEW v_calls AS SELECT src_name AS caller, step, action, target_name AS callee, resolved, src, target
  FROM v_edges WHERE kind='recipe';
CREATE VIEW v_table_use AS SELECT target_name AS tbl, rw, src_name AS recipe, step, action, src, target
  FROM v_edges WHERE kind LIKE '%table%';
CREATE VIEW v_unresolved AS SELECT * FROM v_edges WHERE resolved=0;
CREATE VIEW v_stale_labels AS SELECT src_name, step, label, target_name, src FROM v_edges
  WHERE label IS NOT NULL AND resolved=1 AND label<>target_name;
CREATE VIEW v_pills AS SELECT COALESCE(r.name, p.src) AS src_name, s.number AS step, p.field, p.mode, p.pill_type,
  f.number AS from_step, f.provider||'.'||f.action AS from_action, p.src_path, p.property, p.uid, p.src, p.path
  FROM pills p LEFT JOIN recipes r ON r.recipe=p.src LEFT JOIN steps s ON s.recipe=p.src AND s.path=p.path
  LEFT JOIN steps f ON f.recipe=p.src AND f.path=p.from_path;
CREATE VIEW v_problems AS SELECT COALESCE(r.name, p.src) AS src_name, s.number AS step, p.kind, p.detail, p.src
  FROM problems p LEFT JOIN recipes r ON r.recipe=p.src LEFT JOIN steps s ON s.recipe=p.src AND s.path=p.path;
CREATE VIEW v_column_use AS
  SELECT t.name AS tbl, c.name AS col, c.shared, 'set_or_filter' AS how, COALESCE(r.name, x.src) AS src_name,
    s.number AS step, x.field, x.src
  FROM fields x JOIN columns c ON c.uid=x.uid AND x.src NOT IN (SELECT tbl FROM columns) JOIN assets t ON t.path=c.tbl
    LEFT JOIN recipes r ON r.recipe=x.src LEFT JOIN steps s ON s.recipe=x.src AND s.path=x.path
  UNION ALL
  SELECT t.name, c.name, c.shared, 'read_pill', COALESCE(r.name, p.src), s.number, p.field, p.src
  FROM pills p JOIN columns c ON c.uid=p.uid JOIN assets t ON t.path=c.tbl
    LEFT JOIN recipes r ON r.recipe=p.src LEFT JOIN steps s ON s.recipe=p.src AND s.path=p.path;
'''

def norm(u): return re.sub(r'[-_]', '', u).lower()

def uid_in(s):
    m = UUID.findall(s)
    return norm(m[-1]) if m else None

def sha(obj): return hashlib.sha256(json.dumps(obj, sort_keys=True, default=str).encode()).hexdigest()[:12]

def kind_of(fn):
    p = os.path.basename(fn).split('.')
    return (p[-2] if len(p) > 2 else p[-1]).lower()

def dotted(path):
    return '.'.join('[%s]' % p.get('path_element_type', '?') if isinstance(p, dict) else str(p) for p in path or [])

def walk(node, path='0', depth=0):
    '''The trigger is step '0'; children live under 'block'. A step's identity is its path.'''
    yield path, depth, node
    for i, child in enumerate(node.get('block') or []):
        if isinstance(child, dict):
            yield from walk(child, '%s/%d' % (path, i), depth + 1)

def leaves(o, key=''):
    '''Yield (key path, scalar) for every leaf and (key path, dict) for every asset reference.'''
    if isinstance(o, dict):
        if isinstance(o.get('zip_name'), str):
            yield key, o
            return
        for k, v in o.items():
            sub = '%s.%s' % (key, k) if key else str(k)
            if k in BIG:
                yield sub, json.dumps(v)          # one row per schema blob: searchable, not noisy
            else:
                yield from leaves(v, sub)
    elif isinstance(o, list):
        for i, v in enumerate(o):
            yield from leaves(v, '%s.%d' % (key, i) if key else str(i))
    elif o is not None and o != '':
        yield key, o

def pills_in(s):
    '''Yield (mode, pill dict or None, snippet) for each datapill. Text mode is #{_dp('..')}; formula mode is bare.'''
    for m in DP.finditer(s):
        mode = 'text' if s[max(0, m.start() - 2):m.start()] == '#{' else 'formula'
        pill = None
        for cand in (s[m.end():], s[m.end():m.end() + 4000].replace(BACKSLASH + '"', '"')):
            try:
                pill = DEC.raw_decode(cand)[0]
                break
            except ValueError:
                pass
        yield mode, pill if isinstance(pill, dict) else None, s[m.start():m.start() + 100]
    for m in LEGACY.finditer(s):
        p = m.group(1).split('.')
        yield 'legacy', {'pill_type': 'legacy', 'provider': p[1] if len(p) > 1 else None,
                         'line': p[2] if len(p) > 2 else None, 'path': p[3:]}, m.group(0)

def table_columns(o, depth=0):
    '''Yield (uid, name) for each column of a data table file, whatever the file's exact shape.'''
    if isinstance(o, dict):
        ids = [v for v in o.values() if isinstance(v, str) and UUID.fullmatch(v)]
        if depth and ids and isinstance(o.get('name'), str):
            yield norm(ids[0]), o['name']
        for k, v in o.items():
            if UUID.fullmatch(str(k)) and isinstance(v, dict) and isinstance(v.get('name'), str):
                yield norm(k), v['name']
            yield from table_columns(v, depth + 1)
    elif isinstance(o, list):
        for v in o:
            yield from table_columns(v, depth + 1)

def build(root, dbfile):
    root = os.path.abspath(root)
    if os.path.exists(dbfile):
        os.remove(dbfile)
    db = sqlite3.connect(dbfile)
    db.executescript(SCHEMA)
    files = sorted(os.path.relpath(os.path.join(d, f), root).replace(os.sep, '/')
                   for d, _, fs in os.walk(root) for f in fs)
    fileset, by_base = set(files), {}
    for p in files:
        by_base.setdefault(p.rsplit('/', 1)[-1], []).append(p)

    def resolve(z, src):
        z = z.replace(BACKSLASH, '/').lstrip('/')
        if z in fileset:
            return z
        hits = [p for p in files if p.endswith('/' + z)] or by_base.get(z.rsplit('/', 1)[-1], [])
        if len(hits) > 1:                         # same file name in two projects: prefer the source's own project
            hits = [p for p in hits if p.split('/')[0] == src.split('/')[0]]
        return hits[0] if len(hits) == 1 else None

    def problem(src, path, kind, detail):
        db.execute('INSERT INTO problems VALUES (?,?,?,?)', (src, path, kind, str(detail)[:300]))

    def index(src, path, obj, aliases=None, action=None, labels=None):
        for field, v in leaves(obj):
            last = field.rsplit('.', 1)[-1]
            if isinstance(v, dict):               # a reference to another asset: the binding is zip_name
                z, rw = v['zip_name'], None
                hit, kind = resolve(z, src), kind_of(z)
                if 'table' in kind and action:
                    rw = 'write' if WRITE.search(action) else 'read' if READ.search(action) else None
                label = (labels or {}).get(last)
                db.execute('INSERT INTO edges VALUES (?,?,?,?,?,?,?,?,?)', (
                    src, path, field, kind, hit or z, v.get('name'),
                    label if isinstance(label, str) else None, rw, int(bool(hit))))
                continue
            s = v if isinstance(v, str) else json.dumps(v)
            uid = uid_in(last) or (norm(s) if UUID.fullmatch(s) else None)
            db.execute('INSERT INTO fields VALUES (?,?,?,?,?)', (src, path, field, s, uid))
            if last == 'flow_id' and field.startswith('input'):   # a call target the export could not bind to a file
                db.execute('INSERT INTO edges VALUES (?,?,?,?,?,?,?,?,0)', (src, path, field, 'recipe', s, None, None, None))
            if '_' not in s:
                continue
            for mode, pill, snip in pills_in(s):
                if pill is None:
                    problem(src, path, 'pill_unparsed', '%s: %s' % (field, snip))
                    continue
                line, ptype, ppath = pill.get('line'), str(pill.get('pill_type')), pill.get('path') or []
                frm = (aliases or {}).get(line)
                if line and aliases is not None and frm is None:
                    problem(src, path, 'pill_source_missing', '%s: no step has alias %s' % (field, line))
                prop = pill.get('property_name') or (str(ppath[-1]) if 'property' in ptype and ppath else None)
                db.execute('INSERT INTO pills VALUES (?,?,?,?,?,?,?,?,?,?,?)', (
                    src, path, field, mode, ptype, pill.get('provider'), line, frm,
                    dotted(ppath), uid_in(dotted(ppath)), prop))

    for p in files:
        raw = open(os.path.join(root, p), 'rb').read()
        kind, ext, name, data = kind_of(p), os.path.splitext(p)[1].lower(), os.path.basename(p), None
        if ext == '.json':
            try:
                data = json.loads(raw.decode('utf-8-sig'))
            except ValueError as e:
                problem(p, '', 'json_error', e)
        if isinstance(data, dict) and isinstance(data.get('name'), str):
            name = data['name']
        db.execute('INSERT INTO assets VALUES (?,?,?,?)', (p, kind, name, hashlib.sha256(raw).hexdigest()[:12]))
        if ext in TEXT:                           # connector source and the like: one row per line
            for n, line in enumerate(raw.decode('utf-8', 'replace').splitlines(), 1):
                if line.strip():
                    db.execute('INSERT INTO fields VALUES (?,?,?,?,NULL)', (p, 'L%d' % n, 'line', line))
        if data is None:
            continue
        code = data.get('code') if isinstance(data, dict) else None
        if isinstance(code, str):                 # Developer API dumps carry code as a JSON string
            try:
                code = json.loads(code)
            except ValueError:
                code = None
        if not (isinstance(code, dict) and ('block' in code or 'keyword' in code)):
            index(p, '', data)                    # not a recipe: index the whole file as one unit
            if 'table' in kind:
                for uid, col in set(table_columns(data)):
                    db.execute('INSERT INTO columns(tbl, uid, name) VALUES (?,?,?)', (p, uid, col))
            continue
        steps = list(walk(code))
        aliases = {n.get('as'): path for path, _, n in steps if n.get('as')}
        for path, depth, n in steps:
            own = {k: v for k, v in n.items() if k != 'block'}
            db.execute('INSERT INTO steps VALUES (?,?,?,?,?,?,?,?,?,?,?)', (
                p, path, n.get('number'), depth, n.get('keyword'), n.get('provider'), n.get('name'), n.get('as'),
                n.get('comment'), sha({k: v for k, v in own.items() if k != 'number'}), json.dumps(own)))
            index(p, path, {k: v for k, v in own.items() if k not in HIDE}, aliases, n.get('name'),
                  n.get('dynamicPickListSelection'))
        index(p, '', {k: v for k, v in data.items() if k != 'code'})
        m = CODE.match(name)
        db.execute('INSERT INTO recipes VALUES (?,?,?,?,?,?)', (
            p, name, m.group(1) if m else None, '%s.%s' % (code.get('provider'), code.get('name')),
            len(steps), sha([code, data.get('config')])))

    db.execute('UPDATE columns SET shared=1 WHERE uid IN (SELECT uid FROM columns GROUP BY uid HAVING COUNT(DISTINCT tbl)>1)')
    db.execute("INSERT INTO problems SELECT recipe, '', 'duplicate_code', code FROM recipes WHERE code IN "
               "(SELECT code FROM recipes WHERE code IS NOT NULL GROUP BY code HAVING COUNT(*)>1)")
    db.executemany('INSERT INTO meta VALUES (?,?)', [('source', root), ('files', str(len(files))),
                   ('built', time.strftime('%Y-%m-%d %H:%M')), ('wkfacts', VERSION)])
    db.commit()
    report(db)

def report(db):
    one = lambda sql: db.execute(sql).fetchone()[0]
    pairs = lambda sql: ', '.join('%s %s' % r for r in db.execute(sql)) or '-'
    print('source   :', one("SELECT value FROM meta WHERE key='source'"))
    print('assets   : %d -> %s' % (one('SELECT COUNT(*) FROM assets'),
                                   pairs('SELECT kind, COUNT(*) FROM assets GROUP BY 1 ORDER BY 2 DESC')))
    print('recipes  : %d   steps: %d   fields: %d' % (one('SELECT COUNT(*) FROM recipes'),
                                                      one('SELECT COUNT(*) FROM steps'), one('SELECT COUNT(*) FROM fields')))
    print('edges    : %d (unresolved %d) -> %s' % (one('SELECT COUNT(*) FROM edges'), one('SELECT COUNT(*) FROM edges WHERE resolved=0'),
                                                   pairs('SELECT kind, COUNT(*) FROM edges GROUP BY 1 ORDER BY 2 DESC')))
    print('pills    : %d -> %s' % (one('SELECT COUNT(*) FROM pills'), pairs('SELECT mode, COUNT(*) FROM pills GROUP BY 1')))
    print('columns  : %d in %d tables (%d shared across tables)' % (
        one('SELECT COUNT(*) FROM columns'), one('SELECT COUNT(DISTINCT tbl) FROM columns'),
        one('SELECT COUNT(DISTINCT uid) FROM columns WHERE shared=1')))
    print('problems : %d -> %s' % (one('SELECT COUNT(*) FROM problems'), pairs('SELECT kind, COUNT(*) FROM problems GROUP BY 1')))
    print('actions  :', pairs("SELECT provider||'.'||action, COUNT(*) FROM steps WHERE provider IS NOT NULL "
                              "GROUP BY 1 ORDER BY 2 DESC LIMIT 12"))

def connect(dbfile):
    if not os.path.exists(dbfile):
        sys.exit('no fact store at %s; run build first' % dbfile)
    return sqlite3.connect(pathlib.Path(dbfile).resolve().as_uri() + '?mode=ro', uri=True)

def clip(x, n=160):
    s = '' if x is None else ' '.join(str(x).split())
    return s if len(s) <= n else s[:n] + '...'

def query(db, sql, cap):
    if not sql.lstrip().lower().startswith(('select', 'with')) or ';' in sql.strip().rstrip(';'):
        sys.exit('read-only: one SELECT or WITH statement per call')
    cur = db.execute(sql)
    rows = cur.fetchmany(cap + 1)
    print(TAB.join(d[0] for d in cur.description))
    for r in rows[:cap]:
        print(TAB.join(clip(x) for x in r))
    print('-- %d row(s)%s' % (min(len(rows), cap), ' (TRUNCATED at %d: narrow the query or raise --max)' % cap if len(rows) > cap else ''))

def find(db, text, cap):
    '''Every place a piece of text appears: step inputs, schemas, comments, code, other assets, connector source.'''
    rows = db.execute(
        "SELECT COALESCE(r.name, f.src), s.number, f.path, f.field, f.value FROM fields f "
        "LEFT JOIN recipes r ON r.recipe=f.src LEFT JOIN steps s ON s.recipe=f.src AND s.path=f.path "
        "WHERE instr(lower(f.value), lower(?1)) OR instr(lower(f.field), lower(?1)) ORDER BY 1, f.rowid", (text,)).fetchall()
    for src, num, path, field, value in rows[:cap]:
        i = value.lower().find(text.lower())
        where = 'step %s' % num if num is not None else path or '-'
        print(TAB.join([src, where, field, clip('...' + value[i - 60:] if i > 60 else value)]))
    print('-- %d text hit(s)%s' % (min(len(rows), cap), ' (TRUNCATED at %d: raise --max)' % cap if len(rows) > cap else ''))
    cols = db.execute("SELECT tbl, col, how, src_name, step FROM v_column_use WHERE instr(lower(col), lower(?)) "
                      "ORDER BY 1, 2, 4, 5", (text,)).fetchall()
    for tbl, col, how, src, num in cols[:cap]:
        print(TAB.join(['%s.%s' % (tbl, col), how, src, 'step %s' % num]))
    print('-- %d use(s) of data table columns named like %r (steps hold column uids, so the text search cannot see these)'
          % (min(len(cols), cap), text))

def find_recipe(db, key):
    rows = db.execute('SELECT recipe, name FROM recipes WHERE recipe=?1 OR name=?1', (key,)).fetchall() or db.execute(
        "SELECT recipe, name FROM recipes WHERE name LIKE '%'||?1||'%' OR recipe LIKE '%'||?1||'%'", (key,)).fetchall()
    if len(rows) != 1:
        sys.exit('%d recipes match %r; use the full path:%s' % (len(rows), key, ''.join(NL + '  %s  (%s)' % (n, r) for r, n in rows)))
    return rows[0]

def renderer(db, recipe):
    '''Return a function that shows datapills as <<step: path>> and column uids as column names.'''
    nums = dict(db.execute('SELECT alias, number FROM steps WHERE recipe=? AND alias IS NOT NULL', (recipe,)))
    cols = dict(db.execute('SELECT uid, name FROM columns'))

    def render(s):
        out, pos = [], 0
        for m in DP.finditer(s):
            try:
                pill, end = DEC.raw_decode(s, m.end())
            except ValueError:
                continue
            start = m.start() - 2 if s[max(0, m.start() - 2):m.start()] == '#{' else m.start()
            stop = s.find(')', end) + 1
            if not stop or not isinstance(pill, dict):
                continue
            if start < m.start() and s[stop:stop + 1] == '}':
                stop += 1
            who = nums.get(pill.get('line'), pill.get('pill_type', '?'))
            out += [s[pos:start], '<<%s: %s>>' % ('trigger' if who == 0 else who,
                                                 dotted(pill.get('path')) or pill.get('property_name', ''))]
            pos = stop
        return UUID.sub(lambda u: cols.get(norm(u.group()), u.group()), ''.join(out) + s[pos:])
    return render

def outline(db, key):
    recipe, name = find_recipe(db, key)
    render = renderer(db, recipe)
    print('%s   (%s)' % (name, recipe))
    for path, number, depth, kw, prov, act, comment, node in db.execute(
            'SELECT path, number, depth, keyword, provider, action, comment, node_json FROM steps WHERE recipe=? ORDER BY rowid', (recipe,)):
        bits = ['%s.%s' % (prov, act)] if prov else []
        inp = json.loads(node).get('input')
        if isinstance(inp, dict) and isinstance(inp.get('conditions'), list):
            bits.append((' %s ' % inp.get('operand', 'and')).join(
                render('%s %s %s' % (c.get('lhs', ''), c.get('operand', ''), c.get('rhs', ''))).strip()
                for c in inp['conditions'] if isinstance(c, dict)))
        elif isinstance(inp, dict) and isinstance(inp.get('source'), str):
            bits.append('over ' + render(inp['source']))
        bits += ['-> %s%s%s' % (t, ' [%s]' % rw if rw else '', '' if ok else ' UNRESOLVED') for t, rw, ok in db.execute(
            'SELECT target_name, rw, resolved FROM v_edges WHERE src=? AND path=?', (recipe, path))]
        if comment:
            bits.append('# ' + clip(comment, 70))
        print('%4s %s%-7s %s' % (number, '  ' * depth, kw, '  '.join(bits)))

def step(db, key, number, full):
    recipe, name = find_recipe(db, key)
    render = renderer(db, recipe)
    row = db.execute('SELECT path, keyword, provider, action, alias, comment, node_json FROM steps '
                     'WHERE recipe=? AND number=?', (recipe, int(number))).fetchone()
    if not row:
        sys.exit('no step %s in %s' % (number, name))
    path, kw, prov, act, alias, comment, node = row
    print('%s > step %s   %s %s.%s   path=%s alias=%s' % (name, number, kw, prov, act, path, alias))
    if comment:
        print('  comment: %s' % comment)
    for field, v in leaves({k: v for k, v in json.loads(node).items() if k not in HIDE | {'provider', 'name', 'comment'}}):
        text = v['zip_name'] if isinstance(v, dict) else render(v if isinstance(v, str) else json.dumps(v))
        print('  %s = %s' % (render(field), text if full else clip(text, 600)))
    for t, kind, rw, ok in db.execute('SELECT target_name, kind, rw, resolved FROM v_edges WHERE src=? AND path=?', (recipe, path)):
        print('  uses: %s %s%s%s' % (kind, t, ' [%s]' % rw if rw else '', '' if ok else '  UNRESOLVED'))
    for n, f in db.execute('SELECT s.number, p.field FROM pills p JOIN steps s ON s.recipe=p.src AND s.path=p.path '
                           'WHERE p.src=? AND p.from_path=? ORDER BY s.rowid', (recipe, path)):
        print('  read by: step %s  %s' % (n, render(f)))

def diff(old, new):
    a, b = connect(old), connect(new)
    recs = lambda db: {r: (n, fp) for r, n, fp in db.execute('SELECT recipe, name, fingerprint FROM recipes')}
    stps = lambda db, r: {al or pa: (num, fp, '%s %s' % (kw, '%s.%s' % (pr, ac) if pr else '')) for al, pa, num, fp, kw, pr, ac in db.execute(
        'SELECT alias, path, number, fingerprint, keyword, provider, action FROM steps WHERE recipe=?', (r,))}
    ra, rb = recs(a), recs(b)
    for r in sorted(set(ra) | set(rb)):
        if r not in rb:
            print('- recipe removed: %s  (%s)' % (ra[r][0], r))
        elif r not in ra:
            print('+ recipe added:   %s  (%s)' % (rb[r][0], r))
        elif ra[r][1] != rb[r][1]:
            sa, sb = stps(a, r), stps(b, r)
            lines = [(sa[k][0], '- step %s (old number)  %s' % (sa[k][0], sa[k][2])) for k in sa.keys() - sb.keys()]
            lines += [(sb[k][0], '+ step %s  %s' % (sb[k][0], sb[k][2])) for k in sb.keys() - sa.keys()]
            lines += [(sb[k][0], '~ step %s  %s' % (sb[k][0], sb[k][2])) for k in sa.keys() & sb.keys() if sa[k][1] != sb[k][1]]
            print('~ recipe changed: %s' % rb[r][0])
            for _, text in sorted(lines, key=lambda x: (x[0] or 0, x[1])) or [(0, '(connections or config only)')]:
                print('    ' + text)
    other = lambda db: dict(db.execute('SELECT path, sha FROM assets WHERE path NOT IN (SELECT recipe FROM recipes)'))
    oa, ob = other(a), other(b)
    for p in sorted(set(oa) | set(ob)):
        if p not in ob:
            print('- asset removed:  %s' % p)
        elif p not in oa:
            print('+ asset added:    %s' % p)
        elif oa[p] != ob[p]:
            print('~ asset changed:  %s' % p)

def main():
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('cmd', choices=['build', 'find', 'q', 'outline', 'step', 'diff'])
    ap.add_argument('args', nargs='*')
    ap.add_argument('--db', default='facts.db')
    ap.add_argument('--max', type=int, default=50)
    ap.add_argument('--full', action='store_true')
    o = ap.parse_args()
    need = {'build': 1, 'find': 1, 'q': 1, 'outline': 1, 'step': 2, 'diff': 2}[o.cmd]
    if len(o.args) != need:
        ap.error('%s takes %d argument(s)' % (o.cmd, need))
    if o.cmd == 'build':
        build(o.args[0], o.db)
    elif o.cmd == 'diff':
        diff(*o.args)
    elif o.cmd == 'find':
        find(connect(o.db), o.args[0], o.max)
    elif o.cmd == 'q':
        query(connect(o.db), o.args[0], o.max)
    elif o.cmd == 'outline':
        outline(connect(o.db), o.args[0])
    else:
        step(connect(o.db), o.args[0], o.args[1], o.full)

if __name__ == '__main__':
    main()
```