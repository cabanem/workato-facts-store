---
name: "workato-change-impact"
description: "Use for any request to remove, rename, rewire or change something in Workato recipes, and for what-breaks-if or where-is-X-wired questions. Traces every reference and writes the ordered, by-hand edit list."
---

# Workato change impact

A change to a recipe estate is safe when three things are true:

1. Every reference to the thing was found.
2. The edits run in an order that never leaves a broken pill or a call to something that is gone.
3. A fresh export proves the result.

This skill is the procedure for all three. The facts come from the `workato-recipe-facts` store. If this session has no store for the export, load that skill and build one first. Use its commands (`find`, `outline`, `step`, `q`, `diff`) for every lookup here.

## 1. Name the thing

Turn the request into **seeds**: exact identifiers that can be searched.

A request usually names a behaviour ("the collaborator invite"), not an identifier. Find one anchor with `find`, then read around it with `outline` and `step`. Collect seeds of each kind that applies:

- the recipe or recipes that exist only for this behaviour
- the step or steps that perform it, and the connector action they use
- the parameters and request fields that feed it
- the result and response fields it produces
- the variables that carry its outcome
- the data table columns it reads or writes
- the properties that configure it
- fixed text it writes, such as error messages and status values

Ask the user only when the anchor is ambiguous, for example when two recipes could be the one they mean.

## 2. Close the set

Work through the seeds as a worklist. For each one, follow every relation one hop. Add anything new to the list. Stop when a full pass adds nothing. This is what makes the result complete instead of "the places I thought of".

| Seed | Follow | How |
|---|---|---|
| Step to remove | Steps that read its output | `step X N`, the "read by" lines |
| Recipe to remove | Its callers, endpoints and pages | `v_calls` on `callee` |
| Parameter of a recipe function | Callers that pass it. Steps inside that read it. | `find <name>`; `step X 0` "read by" |
| Result or response field | Callers that read it | `step` on each call step from `v_calls`, the "read by" lines |
| Variable | Steps that set or read it | `step` on the declare step, "read by"; `find <name>` |
| Data table column | Steps that set, filter on or read it | `find <column>` second block; `v_column_use` |
| Property | Steps that read it | `v_pills` on `property` |
| Connector action | Steps that use it. The connector source. | `steps.action`; `find <action>` |
| Request field of an endpoint | Senders outside Workato | Not in the export. See section 4. |

Give every hit one verdict and one reason:

- **Remove**: it exists only for this behaviour.
- **Edit**: it stays, but one mapping, condition or schema field goes.
- **Keep**: something that stays also uses it. Name that user.

Then list the **orphans**: things nothing will use once the edits are done. Examples are a recipe function with no callers left, a column no step touches, a property no step reads, a connector action no step uses, and a connection no recipe binds. Report orphans separately. Removing them is the user's choice.

## 3. Order the edits

One rule: **remove readers before the thing they read.**

- **Inside a recipe.** Edit or delete the steps that read a pill first. Then delete the step that produces it. Change trigger schemas last. Removing a trigger field while a step still maps its pill leaves a broken pill behind.
- **Between recipes.** Edit callers before the function they call. If a parameter is required and the recipes are live, a job can fail between the two saves. Say so, and recommend stopping the caller for the edit.
- **Between tiers.** For a field that crosses an API, use three moves. First the receiver stops using the field but still accepts it. Then every sender stops sending it. Then the receiver drops it from its schema.
- **Shared definitions last.** Delete a column, property, connection, connector action or whole recipe only after a `find` shows no user is left.

Inside one recipe, list the edits from the highest step number to the lowest. Deleting a step renumbers every step after it. Working from the bottom keeps the numbers in the list valid.

## 4. Say what the export cannot show

A static export is one copy of one project at one time. Flag each of these that applies, with the check that would settle it:

- **Senders outside Workato.** Apps Script, other tools or other workspaces that call the endpoints or read the response fields.
- **Other copies.** The same recipes deployed in other workspaces or environments. Say which copy the edit list is for and what must be redeployed.
- **State the behaviour already created.** Removing wiring does not undo what it did. Examples are collaborators already invited, rows already written and tokens already issued. List the cleanup as its own item.
- **Platform settings.** Roles, API client privileges and connector versions that existed only for this behaviour.
- **Assets left out of the export.** If connector source, pages or endpoints are missing from `assets`, the search did not cover them.

Write these as "Not visible from this export: confirm by ...". Do not write them as findings.

## 5. Write the change list

Recipe changes are applied by hand in the Workato editor, so the output is editor instructions. Do not produce a patched recipe JSON unless the user asks for one.

Write plainly. Use short sentences with one idea each. Use this structure:

```text
## Summary
What is changing, in one or two sentences. Which export (folder and date). Counts: recipes, steps, other assets.

## Edits, in order
| # | Where | Step | Do this | Evidence |
One row per edit. "Where" is the recipe name. "Step" is the number and action as `outline` shows them.
"Do this" is one editor action: delete the step, clear one field, remove one schema field.
"Evidence" is the command or step that shows the reference.

## Kept, and why
What looks related but stays, and what still uses it.

## Orphans you may also remove
## Not visible from this export
## How to verify
```

Group the rows by workspace or project when more than one is involved. Put the order of the groups first.

## 6. Verify

After the user makes the edits and exports again:

1. Build a store from the new export.
2. Run `diff old.db new.db`. It should match the edit list: nothing missing, nothing extra.
3. Run `find` again for every seed. Each hit must be on the "Kept" list.
4. Compare `v_problems` and `v_unresolved` with the old store. A new `pill_source_missing` row is a broken pill.

Report the result against the edit list, row by row.